Imports DotNetNuke
Imports System.Web.UI
Imports System.Collections.Generic
Imports System.Reflection
Imports DotNetNuke.Entities.Modules
Namespace YourCompany.Modules.GuestBook
  Partial Class ViewGuestBook
    Inherits Entities.Modules.PortalModuleBase
    Implements Entities.Modules.IActionable
    Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
      Get
        Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
        Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.EditContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.EditContent, "", "", EditUrl(), False, Security.SecurityAccessLevel.Edit, True, False)
        Return Actions
      End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs)
      Try
        Dim objModules As ModuleController = New ModuleController
        If Not Page.IsPostBack Then
          If (Not (CType(Settings("showform"), String)) Is Nothing) Then
            If (CType(Settings("showform"), String) = "No") Then
              ' Do not allow messages to be added
              FormView1.Visible = False
              lblAddMessage.Visible = False
            End If
          End If
        Else
          Me.GridView1.DataBind()
        End If
      Catch ex As Exception
        Exceptions.ProcessModuleLoadException(Me, ex)
      End Try
    End Sub

    Protected Sub NewItem(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.FormViewInsertEventArgs) Handles FormView1.ItemInserting
      e.Values.Item("ID") = 0
      e.Values.Item("ModuleId") = ModuleId.ToString()
      e.Values.Item("DateEntered") = DateTime.Now.ToShortDateString
    End Sub

    Protected Sub SetModuleID(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ObjectDataSourceSelectingEventArgs) Handles ObjectDataSource_Tasks.Selecting
      e.InputParameters("ModuleId") = ModuleId.ToString
    End Sub
  End Class
End Namespace