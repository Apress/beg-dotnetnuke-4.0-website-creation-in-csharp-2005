Imports DotNetNuke
Imports System.Web.UI
Imports System.Collections.Generic
Imports System.Reflection
Imports DotNetNuke.Entities.Modules

Namespace YourCompany.Modules.GuestBook
  Partial Class EditGuestBook
    Inherits PortalModuleBase
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs)
      Try
      Catch exc As Exception
        Exceptions.ProcessModuleLoadException(Me, exc)
      End Try
    End Sub

    Protected Sub SetModuleId(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ObjectDataSourceSelectingEventArgs) Handles ObjectDataSource_Tasks.Selecting
      e.InputParameters("ModuleId") = ModuleId.ToString
    End Sub
  End Class
End Namespace