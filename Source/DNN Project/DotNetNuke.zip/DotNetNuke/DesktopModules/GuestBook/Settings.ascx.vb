Imports System
Imports System.Web.UI
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Services.Exceptions
Namespace YourCompany.Modules.GuestBook
  Partial Class Settings
    Inherits ModuleSettingsBase
    Public Overrides Sub LoadSettings()
      Try
        If (Page.IsPostBack = False) Then
          If (Not (CType(TabModuleSettings("showform"), String)) Is Nothing) Then
            Me.DropDownList1.SelectedValue = CType(TabModuleSettings("showform"), String)
          End If
        End If
      Catch exc As Exception
        Exceptions.ProcessModuleLoadException(Me, exc)
      End Try
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
      Dim objModules As ModuleController = New ModuleController
      If (Me.DropDownList1.SelectedValue = "Yes") Then
        objModules.UpdateTabModuleSetting(TabModuleId, "showform", "Yes")
      Else
        objModules.UpdateTabModuleSetting(TabModuleId, "showform", "No")
      End If
    End Sub
  End Class
End Namespace