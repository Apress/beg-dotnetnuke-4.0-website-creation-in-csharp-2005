'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web.Security

Imports AspNetSecurity = System.Web.Security

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.UI.Skins


Namespace DotNetNuke.Modules.Admin.Security

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Register PortalModuleBase is used to register Users
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''     [cnurse]    10/06/2004  System Messages now handled by Localization
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial  Class Register
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"

        'Register Area


        Protected WithEvents valOldPassword As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valNewPassword As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valNewConfirm1 As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valNewConfirm2 As System.Web.UI.WebControls.CompareValidator

        'tasks

        'services
        Protected WithEvents btnUpdatePassword As System.Web.UI.WebControls.LinkButton

#End Region

#Region "Private Members"

        Private Services As Integer = 0
        Private RoleID As Integer = -1

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' BindData binds the data from the DB to the controls
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindData()

            Dim objModules As New ModuleController
            Dim objPortalController As New PortalController

            userControl.ModuleId = objModules.GetModuleByDefinition(PortalId, "Site Settings").ModuleID
            userControl.StartTabIndex = 1
            addressUser.ModuleId = objModules.GetModuleByDefinition(PortalId, "Site Settings").ModuleID
            addressUser.StartTabIndex = 9

            'Localize the Headers
            DotNetNuke.Services.Localization.Localization.LocalizeDataGrid(grdServices, Me.LocalResourceFile)

            If Services = 1 Then

                UserRow.Visible = False
                PasswordManagementRow.Visible = False

                Dim objUser As New RoleController
                grdServices.DataSource = objUser.GetServices(PortalId)
                grdServices.DataBind()

                If grdServices.Items.Count <> 0 Then
                    lblServices.Text = String.Format(DotNetNuke.Services.Localization.Localization.GetString("PleaseRegister", Me.LocalResourceFile), GetPortalDomainName(PortalAlias.HTTPAlias, Request) & "/" & glbDefaultPage, TabId)
                Else
                    grdServices.Visible = False
                    lblServices.Text = DotNetNuke.Services.Localization.Localization.GetString("MembershipNotOffered", Me.LocalResourceFile)
                End If
                lblServices.Visible = True

                grdServices.Columns(0).Visible = False    ' subscribe
                grdServices.Columns(9).Visible = False    ' expiry date

                ServicesRow.Visible = True
            Else
                UserRow.Visible = True

                'Populate the timezone combobox (look up timezone translations based on currently set culture)
                DotNetNuke.Services.Localization.Localization.LoadTimeZoneDropDownList(cboTimeZone, CType(Page, PageBase).PageCulture.Name, Convert.ToString(PortalSettings.TimeZoneOffset))
                DotNetNuke.Services.Localization.Localization.LoadCultureDropDownList(cboLocale, CultureDropDownTypes.NativeName, CType(Page, PageBase).PageCulture.Name)
                If cboLocale.Items.Count = 1 Then
                    cboLocale.Enabled = False
                End If

                If Request.IsAuthenticated Then

                    lblRegister.Text = DotNetNuke.Services.Localization.Localization.GetString("RegisterNote", Me.LocalResourceFile)
                    cmdRegister.Text = DotNetNuke.Services.Localization.Localization.GetString("cmdUpdate")

                    PasswordManagementRow.Visible = True
                    userControl.ShowPassword = False

                    If UserInfo.UserID >= 0 Then
                        userControl.FirstName = UserInfo.Profile.FirstName
                        userControl.LastName = UserInfo.Profile.LastName
                        userControl.UserName = UserInfo.Membership.Username
                        userControl.Email = UserInfo.Membership.Email
                        userControl.IM = UserInfo.Profile.IM
                        userControl.Website = UserInfo.Profile.Website
                        If Not cboTimeZone.Items.FindByValue(UserInfo.Profile.TimeZone.ToString) Is Nothing Then
                            cboTimeZone.ClearSelection()
                            cboTimeZone.Items.FindByValue(UserInfo.Profile.TimeZone.ToString).Selected = True
                        End If

                        addressUser.Unit = UserInfo.Profile.Unit
                        addressUser.Street = UserInfo.Profile.Street
                        addressUser.City = UserInfo.Profile.City
                        addressUser.Region = UserInfo.Profile.Region
                        addressUser.Country = UserInfo.Profile.Country
                        addressUser.Postal = UserInfo.Profile.PostalCode
                        addressUser.Telephone = UserInfo.Profile.Telephone
                        addressUser.Fax = UserInfo.Profile.Fax
                        addressUser.Cell = UserInfo.Profile.Cell
                        If Not cboLocale.Items.FindByValue(UserInfo.Profile.PreferredLocale) Is Nothing Then
                            cboLocale.ClearSelection()
                            cboLocale.Items.FindByValue(UserInfo.Profile.PreferredLocale).Selected = True
                        End If
                    End If

                    Dim objUser As New RoleController

                    grdServices.DataSource = objUser.GetServices(PortalId, UserInfo.UserID)
                    grdServices.DataBind()

                    If UserInfo.IsSuperUser Then
                        cmdUnregister.Visible = False
                        ServicesRow.Visible = False
                    Else
                        ' if no service available then hide options
                        ServicesRow.Visible = (grdServices.Items.Count > 0)
                    End If
                Else
                    Select Case PortalSettings.UserRegistration
                        Case PortalRegistrationType.PrivateRegistration
                            lblRegister.Text = DotNetNuke.Services.Localization.Localization.GetString("PrivateMembership", Me.LocalResourceFile)
                        Case PortalRegistrationType.PublicRegistration
                            lblRegister.Text = DotNetNuke.Services.Localization.Localization.GetString("PublicMembership", Me.LocalResourceFile)
                        Case PortalRegistrationType.VerifiedRegistration
                            lblRegister.Text = DotNetNuke.Services.Localization.Localization.GetString("VerifiedMembership", Me.LocalResourceFile)
                    End Select
                    lblRegister.Text += DotNetNuke.Services.Localization.Localization.GetString("Required", Me.LocalResourceFile)
                    cmdRegister.Text = DotNetNuke.Services.Localization.Localization.GetString("cmdRegister", Me.LocalResourceFile)

                    cmdUnregister.Visible = False
                    ServicesRow.Visible = False
                    PasswordManagementRow.Visible = False
                    userControl.ShowPassword = True
                End If
            End If

        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatURL correctly formats a URL
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<returns>The correctly formatted url</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FormatURL() As String
            Try

                Dim strServerPath As String

                strServerPath = Request.ApplicationPath
                If Not strServerPath.EndsWith("/") Then
                    strServerPath += "/"
                End If

                Return strServerPath & "Register.aspx?tabid=" & TabId

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatPrice formats the Fee amount and filters out null-values
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="price">The price to format</param>
        '''	<returns>The correctly formatted price</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Function FormatPrice(ByVal price As Single) As String
            Try
                If price <> Null.NullSingle Then
                    FormatPrice = price.ToString("##0.00")
                Else
                    FormatPrice = ""
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatPeriod formats the Period and filters out null-values
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="period">The period to format</param>
        '''	<returns>The correctly formatted period</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Function FormatPeriod(ByVal period As Integer) As String
            Try
                If period <> Null.NullInteger Then
                    FormatPeriod = period.ToString
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatExpiryDate formats the expiry date and filters out null-values
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="DateTime">The date to format</param>
        '''	<returns>The correctly formatted date</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Function FormatExpiryDate(ByVal DateTime As Date) As String
            Try
                If Not Null.IsNull(DateTime) Then
                    FormatExpiryDate = DateTime.ToShortDateString
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ServiceText gets the Service Text (Cancel or Subscribe)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="Subscribed">The service state</param>
        '''	<returns>The correctly formatted text</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ServiceText(ByVal Subscribed As Boolean) As String
            Try
                If Not Subscribed Then
                    ServiceText = DotNetNuke.Services.Localization.Localization.GetString("Subscribe", Me.LocalResourceFile)
                Else
                    ServiceText = DotNetNuke.Services.Localization.Localization.GetString("Unsubscribe", Me.LocalResourceFile)
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ServiceURL correctly formats the Subscription url
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="strKeyName">The key name for the service</param>
        '''	<param name="strKeyValue">The key value for the service</param>
        '''	<param name="objServiceFee">The service fee</param>
        '''	<param name="Subscribed">The service state</param>
        '''	<returns>The correctly formatted url</returns>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ServiceURL(ByVal strKeyName As String, ByVal strKeyValue As String, ByVal objServiceFee As Object, ByVal Subscribed As Boolean) As String
            Try
                Dim dblServiceFee As Double = 0
                Dim ctlRegister As String = ""

                If Not IsDBNull(objServiceFee) Then
                    dblServiceFee = Convert.ToDouble(objServiceFee)
                End If

                If PortalSettings.UserTabId <> -1 Then
                    ' user defined tab
                    ctlRegister = ""
                Else
                    ' admin tab
                    ctlRegister = "Register"
                End If

                If Not Subscribed Then
                    If dblServiceFee > 0 Then
                        ServiceURL = "~/admin/Sales/PayPalSubscription.aspx?tabid=" & TabId & "&" & strKeyName & "=" & strKeyValue
                    Else
                        ServiceURL = NavigateURL(PortalSettings.UserTabId, ctlRegister, strKeyName & "=" & strKeyValue)
                    End If
                Else    ' cancel
                    If dblServiceFee > 0 Then
                        ServiceURL = "~/admin/Sales/PayPalSubscription.aspx?tabid=" & TabId & "&" & strKeyName & "=" & strKeyValue & "&cancel=1"
                    Else
                        ServiceURL = NavigateURL(PortalSettings.UserTabId, ctlRegister, strKeyName & "=" & strKeyValue, "cancel=1")
                    End If
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ' Verify if portal has a customized registration page
                If Not Null.IsNull(PortalSettings.UserTabId) And IsAdminControl() Then
                    ' user page exists and trying to access this control directly with url param -> not allowed
                    Response.Redirect(NavigateURL(PortalSettings.UserTabId))
                End If

                ' Verify that the current user has access to this page
                If PortalSettings.UserRegistration = PortalRegistrationType.NoRegistration And Request.IsAuthenticated = False Then
                    Response.Redirect(NavigateURL("Access Denied"), True)
                End If

                If Not (Request.QueryString("Services") Is Nothing) Then
                    Services = Int32.Parse(Request.QueryString("Services"))
                End If

                ' free subscriptions
                If Not (Request.QueryString("RoleID") Is Nothing) Then
                    RoleID = Int32.Parse(Request.QueryString("RoleID"))

                    Dim objUser As New RoleController

                    Dim objRole As RoleInfo = objUser.GetRole(RoleID, PortalSettings.PortalId)

                    If objRole.IsPublic And objRole.ServiceFee = 0.0 Then
                        objUser.UpdateService(PortalId, UserInfo.UserID, RoleID, Convert.ToBoolean(IIf(Not Request.QueryString("cancel") Is Nothing, True, False)))

                        If PortalSettings.UserTabId <> -1 Then
                            ' user defined tab
                            Response.Redirect(NavigateURL(PortalSettings.UserTabId), True)
                        Else
                            ' admin tab
                            Response.Redirect(NavigateURL("Register"), True)
                        End If
                    Else
                        ' EVENTLOGGER
                    End If
                End If

                ' If this is the first visit to the page, bind the role data to the datalist
                If Page.IsPostBack = False Then
                    UI.Utilities.ClientAPI.AddButtonConfirm(cmdUnregister, DotNetNuke.Services.Localization.Localization.GetString("CancelConfirm", Me.LocalResourceFile))

                    BindData()

                    Try
                        SetFormFocus(userControl)
                    Catch
                        'control not there or error setting focus
                    End Try

                    ' Store URL Referrer to return to portal
                    If Not Request.UrlReferrer Is Nothing Then
                        ViewState("UrlReferrer") = Convert.ToString(Request.UrlReferrer)
                    Else
                        ViewState("UrlReferrer") = ""
                    End If
                End If

                lblRegistration.Text = DotNetNuke.Services.Localization.Localization.GetSystemMessage(PortalSettings, "MESSAGE_REGISTRATION_INSTRUCTIONS")

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdCancel_Click runs when the Cancel Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(Convert.ToString(Viewstate("UrlReferrer")), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdRegister_Click runs when the Register Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [cnurse]    10/06/2004  System Messages now handled by Localization
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRegister_Click(ByVal sender As System.Object, ByVal E As System.EventArgs) Handles cmdRegister.Click
            Try
                ' Only attempt a save/update if all form fields on the page are valid
                If Page.IsValid = True Then

                    ' Add New User to Portal User Database
                    Dim objUser As New UserController
                    Dim objSecurity As New PortalSecurity
                    Dim objModules As New ModuleController

                    If Request.IsAuthenticated Then
                        If userControl.Password <> "" Or userControl.Confirm <> "" Then
                            If userControl.Password <> userControl.Confirm Then
                                UI.Skins.Skin.AddModuleMessage(Me, DotNetNuke.Services.Localization.Localization.GetString("PasswordMatchFailure", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End If
                            Exit Sub
                        End If

                        Dim Username As String = Nothing
                        Dim objUserInfo As UserInfo

                        If UserInfo.UserID >= 0 Then
                            Username = UserInfo.Membership.Username
                        End If

                        objUserInfo = objUser.GetUserByUsername(PortalId, userControl.UserName)

                        'if a user is found with that username and the username isn't our current user's username
                        If Not objUserInfo Is Nothing And userControl.UserName <> Username Then
                            'username already exists in DB so show user an error
                            UI.Skins.Skin.AddModuleMessage(Me, String.Format(DotNetNuke.Services.Localization.Localization.GetString("RegistrationFailure", Me.LocalResourceFile), userControl.UserName), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        Else
                            'update the user
                            objUserInfo.UserID = UserInfo.UserID
                            objUserInfo.PortalID = PortalId
                            objUserInfo.Profile.FirstName = userControl.FirstName
                            objUserInfo.Profile.LastName = userControl.LastName
                            objUserInfo.Profile.Unit = addressUser.Unit
                            objUserInfo.Profile.Street = addressUser.Street
                            objUserInfo.Profile.City = addressUser.City
                            objUserInfo.Profile.Region = addressUser.Region
                            objUserInfo.Profile.PostalCode = addressUser.Postal
                            objUserInfo.Profile.Country = addressUser.Country
                            objUserInfo.Profile.Telephone = addressUser.Telephone
                            objUserInfo.Membership.Email = userControl.Email
                            objUserInfo.Membership.Username = userControl.UserName
                            objUserInfo.Profile.Cell = addressUser.Cell
                            objUserInfo.Profile.Fax = addressUser.Fax
                            objUserInfo.Profile.IM = userControl.IM
                            objUserInfo.Profile.Website = userControl.Website
                            objUserInfo.Profile.PreferredLocale = cboLocale.SelectedItem.Value
                            objUserInfo.Profile.TimeZone = Convert.ToInt32(cboTimeZone.SelectedItem.Value)

                            objUser.UpdateUser(objUserInfo)

                            'store preferredlocale in cookie
                            CType(Page, PageBase).SetLanguage(objUserInfo.Profile.PreferredLocale)

                            'clear the portal cache if current user is portal administrator (catch email adress changes)
                            If UserInfo.UserID = PortalSettings.AdministratorId Then
                                DataCache.ClearPortalCache(PortalId, True)
                            End If
                            ' Redirect browser back to home page
                            Response.Redirect(Convert.ToString(Viewstate("UrlReferrer")), True)
                        End If

                    Else
                        Dim objUserInfo As UserInfo
                        objUserInfo = objUser.GetUserByUsername(PortalId, userControl.UserName)

                        'if a user is found with that username, error.
                        'this prevents you from adding a username
                        'with the same name as a superuser.
                        If Not objUserInfo Is Nothing Then
                            'username already exists in DB so show user an error
                            UI.Skins.Skin.AddModuleMessage(Me, String.Format(DotNetNuke.Services.Localization.Localization.GetString("RegistrationFailure", Me.LocalResourceFile), userControl.UserName), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            Exit Sub
                        End If

                        Dim AffiliateId As Integer = Null.NullInteger
                        If Not Request.Cookies("AffiliateId") Is Nothing Then
                            AffiliateId = Integer.Parse(Request.Cookies("AffiliateId").Value)
                        End If

                        Dim objNewUser As New UserInfo
                        objNewUser.PortalID = PortalId
                        objNewUser.Profile.FirstName = userControl.FirstName
                        objNewUser.Profile.LastName = userControl.LastName
                        objNewUser.Profile.Unit = addressUser.Unit
                        objNewUser.Profile.Street = addressUser.Street
                        objNewUser.Profile.City = addressUser.City
                        objNewUser.Profile.Region = addressUser.Region
                        objNewUser.Profile.PostalCode = addressUser.Postal
                        objNewUser.Profile.Country = addressUser.Country
                        objNewUser.Profile.Telephone = addressUser.Telephone
                        objNewUser.Membership.Email = userControl.Email
                        objNewUser.Membership.Username = userControl.UserName
                        objNewUser.Membership.Password = userControl.Password
                        objNewUser.Membership.Approved = Convert.ToBoolean(IIf(PortalSettings.UserRegistration <> PortalRegistrationType.PublicRegistration, False, True))
                        objNewUser.AffiliateID = AffiliateId
                        objNewUser.Profile.Cell = addressUser.Cell
                        objNewUser.Profile.Fax = addressUser.Fax
                        objNewUser.Profile.IM = userControl.IM
                        objNewUser.Profile.Website = userControl.Website
                        objNewUser.Profile.PreferredLocale = cboLocale.SelectedItem.Value
                        objNewUser.Profile.TimeZone = Convert.ToInt32(cboTimeZone.SelectedItem.Value)

                        objNewUser.UserID = objUser.AddUser(objNewUser)

                        If objNewUser.UserID >= 0 Then

                            Dim objEventLog As New Services.Log.EventLog.EventLogController
                            objEventLog.AddLog(objNewUser, PortalSettings, UserId, userControl.UserName, DotNetNuke.Services.Log.EventLog.EventLogController.EventLogType.USER_CREATED)

                            ' send notification to portal administrator of new user registration
                            Mail.SendMail(PortalSettings.Email, PortalSettings.Email, "", _
                                DotNetNuke.Services.Localization.Localization.GetSystemMessage(PortalSettings.DefaultLanguage, PortalSettings, "EMAIL_USER_REGISTRATION_ADMINISTRATOR_SUBJECT", objNewUser), _
                                DotNetNuke.Services.Localization.Localization.GetSystemMessage(PortalSettings.DefaultLanguage, PortalSettings, "EMAIL_USER_REGISTRATION_ADMINISTRATOR_BODY", objNewUser), _
                                "", "", "", "", "", "")

                            ' complete registration
                            Dim strMessage As String = ""
                            Select Case PortalSettings.UserRegistration
                                Case PortalRegistrationType.PrivateRegistration
                                    Mail.SendMail(PortalSettings.Email, userControl.Email, "", _
                                        DotNetNuke.Services.Localization.Localization.GetSystemMessage(objNewUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PRIVATE_SUBJECT", objNewUser), _
                                        DotNetNuke.Services.Localization.Localization.GetSystemMessage(objNewUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PRIVATE_BODY", objNewUser), _
                                        "", "", "", "", "", "")
                                    'show a message that a portal administrator has to verify the user credentials
                                    strMessage = String.Format(DotNetNuke.Services.Localization.Localization.GetString("PrivateConfirmationMessage", Me.LocalResourceFile), userControl.Email)
                                Case PortalRegistrationType.PublicRegistration
                                    objSecurity.UserLogin(userControl.UserName, userControl.Password, PortalSettings.PortalId, PortalSettings.PortalName, "", False)
                                Case PortalRegistrationType.VerifiedRegistration
                                    Mail.SendMail(PortalSettings.Email, userControl.Email, "", _
                                        DotNetNuke.Services.Localization.Localization.GetSystemMessage(objNewUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PUBLIC_SUBJECT", objNewUser), _
                                        DotNetNuke.Services.Localization.Localization.GetSystemMessage(objNewUser.Profile.PreferredLocale, PortalSettings, "EMAIL_USER_REGISTRATION_PUBLIC_BODY", objNewUser), _
                                        "", "", "", "", "", "")
                                    'show a message that an email has been send with the registration details
                                    strMessage = String.Format(DotNetNuke.Services.Localization.Localization.GetString("VerifiedConfirmationMessage", Me.LocalResourceFile), userControl.Email)
                            End Select

                            ' affiliate
                            If Not Null.IsNull(AffiliateId) Then
                                Dim objAffiliates As New Services.Vendors.AffiliateController
                                objAffiliates.UpdateAffiliateStats(AffiliateId, 0, 1)
                            End If

                            'store preferredlocale in cookie
                            CType(Page, PageBase).SetLanguage(objNewUser.Profile.PreferredLocale)

                            If Not strMessage.Length = 0 Then
                                UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
                                UserRow.Visible = False
                                cmdRegister.Visible = False
                                cmdUnregister.Visible = False
                                cmdCancel.Visible = False
                            Else
                                ' Redirect browser back to home page
                                Response.Redirect(Convert.ToString(Viewstate("UrlReferrer")), True)
                            End If
                        Else       ' registration error
                            Dim UserRegistrationStatus As AspNetSecurity.MembershipCreateStatus
                            UserRegistrationStatus = CType(objNewUser.UserID * -1, AspNetSecurity.MembershipCreateStatus)
                            Dim objUserController As New UserController
                            UI.Skins.Skin.AddModuleMessage(Me, objUserController.GetRegistrationStatus(UserRegistrationStatus), UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        End If
                    End If

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUnregister_Click runs when the UnRegister Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUnregister_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUnregister.Click
            Try
                Dim users As New UserController
                users.DeleteUser(PortalId, UserId)

                Response.Redirect("~/Admin/Security/Logoff.aspx?portalid=" & PortalSettings.PortalId.ToString)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdatePassword_Click runs when the Update Pasword Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/13/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdatePassword_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdatePassword.Click
            If txtOldPassword.Text = "" Then
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("OldPassword", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
                Exit Sub
            End If
            If txtNewPassword.Text = "" Or txtNewConfirm.Text = "" Then
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("NewPassword", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
                Exit Sub
            End If
            If txtNewPassword.Text <> txtNewConfirm.Text Then
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("PasswordMatchFailure", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
                Exit Sub
            End If
            Dim objUserController As New UserController


            If objUserController.SetPassword(UserInfo, txtOldPassword.Text, txtNewPassword.Text) Then
                'Success
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("PasswordChanged", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess))
            Else
                'Fail
                MessageCell.Controls.Add(UI.Skins.Skin.GetModuleMessageControl("", DotNetNuke.Services.Localization.Localization.GetString("PasswordUpdateFailed", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning))
            End If
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
