'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Services.Mail
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Modules.Admin.Security

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The SecurityRoles PortalModuleBase is used to manage the users and roles they
	''' have
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
	Partial  Class SecurityRoles

		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"



#End Region

#Region "Private Members"

		Private RoleId As Integer = -1
		Private Shadows UserId As Integer = -1

#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' BindData loads the controls from the Database
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub BindData()

			Dim objRoles As New RoleController
			Dim objUsers As New UserController

			' bind all portal roles to dropdownlist
			If RoleId = -1 Then
				cboRoles.DataSource = objRoles.GetPortalRoles(PortalId)
				cboRoles.DataBind()
			Else
                Dim objRole As RoleInfo = objRoles.GetRole(RoleId, PortalId)
				If Not objRole Is Nothing Then
					cboRoles.Items.Add(New ListItem(objRole.RoleName, objRole.RoleID.ToString))
					cboRoles.Items(0).Selected = True
                    lblTitle.Text = String.Format(Localization.GetString("RoleTitle.Text", LocalResourceFile), objRole.RoleName, objRole.RoleID.ToString)
                End If
                cmdAdd.Text = String.Format(Localization.GetString("AddUser.Text", LocalResourceFile), objRole.RoleName)
                cboRoles.Visible = False
                plRoles.Visible = False
            End If

            ' bind all portal users to dropdownlist
            If UserId = -1 Then
                cboUsers.DataSource = objUsers.GetUsers(PortalId, False, False)
                cboUsers.DataBind()
            Else
                Dim objUser As UserInfo = objUsers.GetUser(PortalId, UserId)
                If Not objUser Is Nothing Then
                    cboUsers.Items.Add(New ListItem(objUser.Profile.FullName, objUser.UserID.ToString))
                    cboUsers.Items(0).Selected = True
                    lblTitle.Text = String.Format(Localization.GetString("UserTitle.Text", LocalResourceFile), objUser.Profile.FullName, objUser.UserID.ToString)
                End If
                cmdAdd.Text = String.Format(Localization.GetString("AddRole.Text", LocalResourceFile), objUser.Profile.FullName)
                cboUsers.Visible = False
                plUsers.Visible = False
            End If

            chkNotify.Checked = True

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
        ''' BindGrid loads the data grid from the Database
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub BindGrid()

			Dim objRoleController As New RoleController

            If RoleId <> -1 Then
                Dim RoleName As String = objRoleController.GetRole(RoleId, PortalId).RoleName
                grdUserRoles.DataKeyField = "UserId"
                grdUserRoles.Columns(2).Visible = False
                grdUserRoles.DataSource = objRoleController.GetUsersInRole(PortalId, RoleName)
                grdUserRoles.DataBind()
            End If
            If UserId <> -1 Then
                Dim objUserController As New UserController
                Dim objUserInfo As UserInfo = objUserController.GetUser(PortalId, UserId)
                grdUserRoles.DataKeyField = "RoleId"
                grdUserRoles.Columns(1).Visible = False
                grdUserRoles.DataSource = objRoleController.GetUserRolesByUsername(PortalId, objUserInfo.Username, Null.NullString)
                grdUserRoles.DataBind()
            End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' GetExpiryDate gets the expiry Dtae of a Users Role membership
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="UserId">The Id of the User</param>
		''' <param name="RoleId">The Id of the Role</param>
		''' <history>
		''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function GetExpiryDate(ByVal UserId As Integer, ByVal RoleId As Integer) As String

			Dim strExpiryDate As String = ""

			Dim objRoles As New RoleController
			Dim objUserRole As UserRoleInfo = objRoles.GetUserRole(PortalId, UserId, RoleId)
			If Not objUserRole Is Nothing Then
				If Null.IsNull(objUserRole.ExpiryDate) = False Then
					strExpiryDate = objUserRole.ExpiryDate.ToShortDateString
				End If
			Else			 ' new role assignment
                Dim objRole As RoleInfo = objRoles.GetRole(RoleId, PortalId)

				Select Case objRole.BillingFrequency
					Case "D" : strExpiryDate = DateAdd(DateInterval.Day, objRole.BillingPeriod, Now).ToShortDateString
					Case "W" : strExpiryDate = DateAdd(DateInterval.Day, (objRole.BillingPeriod * 7), Now).ToShortDateString
					Case "M" : strExpiryDate = DateAdd(DateInterval.Month, objRole.BillingPeriod, Now).ToShortDateString
					Case "Y" : strExpiryDate = DateAdd(DateInterval.Year, objRole.BillingPeriod, Now).ToShortDateString
				End Select
			End If

			Return strExpiryDate

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' SendNotification sends an email notification to the user of the change in his/her role
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="UserId">The Id of the User</param>
		''' <param name="RoleId">The Id of the Role</param>
		''' <history>
		''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub SendNotification(ByVal UserId As Integer, ByVal RoleId As Integer, ByVal Action As String)

			Dim objUsers As New UserController
			Dim objUser As UserInfo = objUsers.GetUser(PortalId, UserId)

			Dim objRoles As New RoleController
            Dim objRole As RoleInfo = objRoles.GetRole(RoleId, PortalId)

			Dim Custom As New ArrayList
			Custom.Add(objRole.RoleName)
			Custom.Add(objRole.Description)

            Select Case Action
                Case "add"
                    Dim objUserRole As UserRoleInfo = objRoles.GetUserRole(PortalId, UserId, RoleId)
                    Custom.Add(objUserRole.ExpiryDate.ToString)
                    Mail.SendMail(PortalSettings.Email, objUser.Membership.Email, "", _
                        Services.Localization.Localization.GetSystemMessage(objUser.Profile.PreferredLocale, PortalSettings, "EMAIL_ROLE_ASSIGNMENT_SUBJECT", objUser), _
                        Services.Localization.Localization.GetSystemMessage(objUser.Profile.PreferredLocale, PortalSettings, "EMAIL_ROLE_ASSIGNMENT_BODY", objUser, Services.Localization.Localization.GlobalResourceFile, Custom), _
                        "", "", "", "", "", "")
                Case "remove"
                    Custom.Add("")
                    Mail.SendMail(PortalSettings.Email, objUser.Membership.Email, "", _
                        Services.Localization.Localization.GetSystemMessage(objUser.Profile.PreferredLocale, PortalSettings, "EMAIL_ROLE_UNASSIGNMENT_SUBJECT", objUser), _
                        Services.Localization.Localization.GetSystemMessage(objUser.Profile.PreferredLocale, PortalSettings, "EMAIL_ROLE_UNASSIGNMENT_BODY", objUser, Services.Localization.Localization.GlobalResourceFile, Custom), _
                        "", "", "", "", "", "")
            End Select

		End Sub

#End Region

#Region "Public Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' FormatExpiryDate formats the expiry date and filters out nulls
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="DateTime">The Date object to frormat</param>
		''' <history>
		''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Function FormatExpiryDate(ByVal DateTime As Date) As String
			Try
				If Not Null.IsNull(DateTime) Then
					FormatExpiryDate = DateTime.ToShortDateString
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [VMasanas]  9/28/2004   Changed redirect to Access Denied
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                ' Verify that the current user has access to this page
                If PortalSecurity.IsInRoles(PortalSettings.AdministratorRoleName) = False Then
                    Response.Redirect(NavigateURL("Access Denied"), True)
                End If

                If Not (Request.QueryString("RoleId") Is Nothing) Then
                    RoleId = Int32.Parse(Request.QueryString("RoleId"))
                End If

                If Not (Request.QueryString("UserId") Is Nothing) Then
                    UserId = Int32.Parse(Request.QueryString("UserId"))
                End If

                'this needs to execute always to the client script code is registred in InvokePopupCal
                cmdExpiryCalendar.NavigateUrl = Common.Utilities.Calendar.InvokePopupCal(txtExpiryDate)

                ' If this is the first visit to the page, bind the role data to the datalist
                If Page.IsPostBack = False Then

                    'Localize Headers
                    Services.Localization.Localization.LocalizeDataGrid(grdUserRoles, Me.LocalResourceFile)

                    BindData()

                    ' Store URL Referrer to return to portal
                    If Not Request.UrlReferrer Is Nothing Then
                        ViewState("UrlReferrer") = Convert.ToString(Request.UrlReferrer)
                    Else
                        ViewState("UrlReferrer") = ""
                    End If
                End If

                BindGrid()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cboUsers_SelectedIndexChanged runs when the selected User is changed in the
        ''' Users Drop-Down
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cboUsers_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboUsers.SelectedIndexChanged
            If (Not cboUsers.SelectedItem Is Nothing) And (Not cboRoles.SelectedItem Is Nothing) Then
                txtExpiryDate.Text = GetExpiryDate(Int32.Parse(cboUsers.SelectedItem.Value), Int32.Parse(cboRoles.SelectedItem.Value))
            End If
            BindGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cboRoles_SelectedIndexChanged runs when the selected Role is changed in the
        ''' Roles Drop-Down
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cboRoles_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRoles.SelectedIndexChanged
            If (Not cboUsers.SelectedItem Is Nothing) And (Not cboRoles.SelectedItem Is Nothing) Then
                txtExpiryDate.Text = GetExpiryDate(Int32.Parse(cboUsers.SelectedItem.Value), Int32.Parse(cboRoles.SelectedItem.Value))
            End If
            BindGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdAdd_Click runs when the Update Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
            Try

                Dim objUserController As New UserController
                Dim objRoleController As New RoleController

                ' do not expire the portal Administrator account
                If cboUsers.SelectedItem.Value = PortalSettings.AdministratorId.ToString And cboRoles.SelectedItem.Value = PortalSettings.AdministratorRoleId.ToString Then
                    txtExpiryDate.Text = ""
                End If

                Dim datExpiryDate As Date
                If txtExpiryDate.Text <> "" Then
                    datExpiryDate = Date.Parse(txtExpiryDate.Text)
                Else
                    datExpiryDate = Null.NullDate
                End If
                Dim objEventLog As New Services.log.EventLog.EventLogController
                If (Not cboRoles.SelectedItem Is Nothing) And (Not cboUsers.SelectedItem Is Nothing) Then
                    ' update assignment
                    objRoleController.AddUserRole(PortalId, Convert.ToInt32(cboUsers.SelectedItem.Value), Convert.ToInt32(cboRoles.SelectedItem.Value), datExpiryDate)
					objEventLog.AddLog("Role", cboRoles.SelectedItem.Text, PortalSettings, UserId, Services.Log.EventLog.EventLogController.EventLogType.USER_ROLE_CREATED)

                    ' send notification
                    If chkNotify.Checked Then
                        SendNotification(Convert.ToInt32(cboUsers.SelectedItem.Value), Convert.ToInt32(cboRoles.SelectedItem.Value), "add")
                    End If
                End If

                BindGrid()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdCancel_Click runs when the Delete Button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try

                Response.Redirect(Convert.ToString(Viewstate("UrlReferrer")), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' grdUserRoles_Delete runs when one of the Delete Buttons in the UserRoles Grid
        ''' is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub grdUserRoles_Delete(ByVal sender As Object, ByVal e As DataGridCommandEventArgs)
            Try

                Dim objUser As New RoleController
                Dim strMessage As String = ""

                If RoleId <> -1 Then
                    If objUser.DeleteUserRole(PortalId, Integer.Parse(Convert.ToString(grdUserRoles.DataKeys(e.Item.ItemIndex))), RoleId) = False Then
                        strMessage = Services.Localization.Localization.GetString("RoleRemoveError", Me.LocalResourceFile)
                    Else
                        If chkNotify.Checked Then
                            SendNotification(Integer.Parse(Convert.ToString(grdUserRoles.DataKeys(e.Item.ItemIndex))), RoleId, "remove")
                        End If
                    End If
                End If
                If UserId <> -1 Then
                    If objUser.DeleteUserRole(PortalId, UserId, Integer.Parse(Convert.ToString(grdUserRoles.DataKeys(e.Item.ItemIndex)))) = False Then
                        strMessage = Services.Localization.Localization.GetString("RoleRemoveError", Me.LocalResourceFile)
                    Else
                        If chkNotify.Checked Then
                            SendNotification(UserId, Integer.Parse(Convert.ToString(grdUserRoles.DataKeys(e.Item.ItemIndex))), "remove")
                        End If
                    End If
                End If

                grdUserRoles.EditItemIndex = -1
                BindGrid()

                If strMessage <> "" Then
                    UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' grdUserRoles_ItemCreated runs when an item in the UserRoles Grid is created
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/10/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub grdUserRoles_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles grdUserRoles.ItemCreated
            Try

                Dim cmdDeleteUserRole As Control = e.Item.FindControl("cmdDeleteUserRole")

				If Not cmdDeleteUserRole Is Nothing Then
                    ClientAPI.AddButtonConfirm(CType(cmdDeleteUserRole, ImageButton), Services.Localization.Localization.GetString("DeleteItem"))
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
