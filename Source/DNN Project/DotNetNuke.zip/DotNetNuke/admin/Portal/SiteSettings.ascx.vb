'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Services.FileSystem
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Modules.Admin.PortalManagement

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The SiteSettings PortalModuleBase is used to edit the main settings for a 
    ''' portal.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Partial  Class SiteSettings
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"

        'Settings

        'Basic Settings Section

        'Site Section

        'Appearance Section

        'Advanced Settings Section

        'Security Section
        Protected dshSecurity As UI.UserControls.SectionHeadControl

        'Pages Section

        'Payment Section

        'Other Section
        Protected dshOther As UI.UserControls.SectionHeadControl
        Protected plAdministratorId As UI.UserControls.LabelControl

        'Host Section

        'Stylesheet
        Protected pnlStyleSheet As System.Web.UI.WebControls.Panel
        Protected lblStyleSheet As System.Web.UI.WebControls.Label

        'Tasks

        Protected WithEvents tblHostingDetails As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents txtPortalAlias As System.Web.UI.WebControls.TextBox

#End Region

#Region "Private Members"

        Dim intPortalId As Integer = -1

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' LoadStyleSheet loads the stylesheet
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub LoadStyleSheet()

            Dim strUploadDirectory As String = ""

            Dim objPortalController As New PortalController
            Dim objPortal As PortalInfo = objPortalController.GetPortal(intPortalId)
            If Not objPortal Is Nothing Then
                strUploadDirectory = objPortal.HomeDirectoryMapPath
            End If

            ' read CSS file
            If System.IO.File.Exists(strUploadDirectory & "portal.css") Then
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(strUploadDirectory & "portal.css")
                txtStyleSheet.Text = objStreamReader.ReadToEnd
                objStreamReader.Close()
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' SkinChanged changes the skin
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/19/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function SkinChanged(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal SkinType As DotNetNuke.ui.Skins.SkinType, ByVal PostedSkinSrc As String) As Boolean
            Dim objSkinInfo As UI.Skins.SkinInfo
            Dim strSkinSrc As String = ""
            objSkinInfo = SkinController.GetSkin(SkinRoot, PortalId, SkinType.Admin)
            If Not objSkinInfo Is Nothing Then strSkinSrc = objSkinInfo.SkinSrc
            If strSkinSrc Is Nothing Then strSkinSrc = ""
            Return strSkinSrc <> PostedSkinSrc
        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatCurrency formats the currency.
        ''' control.
        ''' </summary>
        ''' <returns>A formatted string</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FormatCurrency() As String

            Dim retValue As String = ""
            Try
                retValue = Convert.ToString(Common.Globals.HostSettings("HostCurrency")) & " / " & Services.Localization.Localization.GetString("Month")
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatFee formats the fee.
        ''' control.
        ''' </summary>
        ''' <returns>A formatted string</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FormatFee(ByVal objHostFee As Object) As String
            Dim retValue As String = ""

            Try
                'TODO - this needs to be localised
                If Not IsDBNull(objHostFee) Then
                    retValue = Format(objHostFee, "#,##0.00")
                Else
                    retValue = "0"
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' IsSubscribed determines whether the portal has subscribed to the premium 
        ''' control.
        ''' </summary>
        ''' <returns>True if Subscribed, False if not</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function IsSubscribed(ByVal PortalModuleDefinitionId As Integer) As Boolean
            Try
                Return Null.IsNull(PortalModuleDefinitionId) = False

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' IsSuperUser determines whether the cuurent user is a SuperUser
        ''' control.
        ''' </summary>
        ''' <returns>True if SuperUser, False if not</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/4/2004	Added
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function IsSuperUser() As Boolean

            Return Me.UserInfo.IsSuperUser

        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not (Request.QueryString("pid") Is Nothing) And (PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Or UserInfo.IsSuperUser) Then
                    intPortalId = Int32.Parse(Request.QueryString("pid"))
                    ctlLogo.ShowUpLoad = False
                    ctlBackground.ShowUpLoad = False
                Else
                    intPortalId = PortalId
                    ctlLogo.ShowUpLoad = True
                    ctlBackground.ShowUpLoad = True
                End If

                'this needs to execute always to the client script code is registred in InvokePopupCal
                cmdExpiryCalendar.NavigateUrl = Common.Utilities.Calendar.InvokePopupCal(txtExpiryDate)
                ClientAPI.AddButtonConfirm(cmdRestore, Services.Localization.Localization.GetString("RestoreCCSMessage", Me.LocalResourceFile))

                ' If this is the first visit to the page, populate the site data
                If Page.IsPostBack = False Then

                    ClientAPI.AddButtonConfirm(cmdDelete, Services.Localization.Localization.GetString("DeleteMessage", Me.LocalResourceFile))

                    Dim objPortalController As New PortalController
                    Dim objModules As New ModuleController
                    Dim objUsers As New UserController
                    Dim ctlList As New Common.Lists.ListController
                    Dim colProcessor As Common.Lists.ListEntryInfoCollection = ctlList.GetListEntryInfoCollection("Processor")

                    cboProcessor.DataSource = colProcessor
                    cboProcessor.DataBind()
                    cboProcessor.Items.Insert(0, New ListItem("<" + Services.Localization.Localization.GetString("None_Specified") + ">", ""))

                    Dim objPortal As PortalInfo = objPortalController.GetPortal(intPortalId)

                    txtPortalName.Text = objPortal.PortalName
                    ctlLogo.Url = objPortal.LogoFile
                    ctlLogo.FileFilter = glbImageFileTypes
                    txtDescription.Text = objPortal.Description
                    txtKeyWords.Text = objPortal.KeyWords
                    ctlBackground.Url = objPortal.BackgroundFile
                    ctlBackground.FileFilter = glbImageFileTypes
                    txtFooterText.Text = objPortal.FooterText
                    optUserRegistration.SelectedIndex = objPortal.UserRegistration
                    optBannerAdvertising.SelectedIndex = objPortal.BannerAdvertising

                    cboSplashTabId.DataSource = GetPortalTabs(intPortalId, True, True, False, False, False)
                    cboSplashTabId.DataBind()
                    If Not cboSplashTabId.Items.FindByValue(objPortal.SplashTabId.ToString) Is Nothing Then
                        cboSplashTabId.Items.FindByValue(objPortal.SplashTabId.ToString).Selected = True
                    End If
                    cboHomeTabId.DataSource = GetPortalTabs(intPortalId, True, True, False, False, False)
                    cboHomeTabId.DataBind()
                    If Not cboHomeTabId.Items.FindByValue(objPortal.HomeTabId.ToString) Is Nothing Then
                        cboHomeTabId.Items.FindByValue(objPortal.HomeTabId.ToString).Selected = True
                    End If
                    cboLoginTabId.DataSource = GetPortalTabs(intPortalId, True, True, False, False, False)
                    cboLoginTabId.DataBind()
                    If Not cboLoginTabId.Items.FindByValue(objPortal.LoginTabId.ToString) Is Nothing Then
                        cboLoginTabId.Items.FindByValue(objPortal.LoginTabId.ToString).Selected = True
                    End If
                    cboUserTabId.DataSource = GetPortalTabs(intPortalId, True, True, False, False, False)
                    cboUserTabId.DataBind()
                    If Not cboUserTabId.Items.FindByValue(objPortal.UserTabId.ToString) Is Nothing Then
                        cboUserTabId.Items.FindByValue(objPortal.UserTabId.ToString).Selected = True
                    End If

                    Dim colList As Common.Lists.ListEntryInfoCollection = ctlList.GetListEntryInfoCollection("Currency")

                    cboCurrency.DataSource = colList
                    cboCurrency.DataBind()
                    If Null.IsNull(objPortal.Currency) Or cboCurrency.Items.FindByValue(objPortal.Currency) Is Nothing Then
                        cboCurrency.Items.FindByValue("USD").Selected = True
                    Else
                        cboCurrency.Items.FindByValue(objPortal.Currency).Selected = True
                    End If
                    Dim objRoleController As New DotNetNuke.Security.Roles.RoleController

                    Dim Arr As ArrayList = objRoleController.GetUsersInRole(intPortalId, objPortal.AdministratorRoleName)
                    Dim i As Integer
                    For i = 0 To Arr.Count - 1
                        Dim objUser As UserRoleInfo = CType(Arr(i), UserRoleInfo)
                        cboAdministratorId.Items.Add(New ListItem(objUser.FullName, objUser.UserID.ToString))
                    Next
                    If Not cboAdministratorId.Items.FindByValue(objPortal.AdministratorId.ToString) Is Nothing Then
                        cboAdministratorId.Items.FindByValue(objPortal.AdministratorId.ToString).Selected = True
                    End If

                    If Not Null.IsNull(objPortal.ExpiryDate) Then
                        txtExpiryDate.Text = objPortal.ExpiryDate.ToShortDateString
                    End If
                    txtHostFee.Text = objPortal.HostFee.ToString
                    txtHostSpace.Text = objPortal.HostSpace.ToString
                    If Not IsDBNull(objPortal.SiteLogHistory) Then
                        txtSiteLogHistory.Text = objPortal.SiteLogHistory.ToString
                    End If

                    Dim objDesktopModules As New DesktopModuleController
                    Dim arrDesktopModules As ArrayList = objDesktopModules.GetDesktopModules

                    Dim arrPremiumModules As New ArrayList
                    Dim objDesktopModule As DesktopModuleInfo
                    For Each objDesktopModule In arrDesktopModules
                        If objDesktopModule.IsPremium Then
                            arrPremiumModules.Add(objDesktopModule)
                        End If
                    Next

                    Dim arrPortalDesktopModules As ArrayList = objDesktopModules.GetPortalDesktopModules(intPortalId, Null.NullInteger)
                    Dim objPortalDesktopModule As PortalDesktopModuleInfo
                    For Each objPortalDesktopModule In arrPortalDesktopModules
                        For Each objDesktopModule In arrPremiumModules
                            If objDesktopModule.DesktopModuleID = objPortalDesktopModule.DesktopModuleID Then
                                arrPremiumModules.Remove(objDesktopModule)
                                Exit For
                            End If
                        Next
                    Next

                    ctlDesktopModules.Available = arrPremiumModules
                    ctlDesktopModules.Assigned = arrPortalDesktopModules

                    If objPortal.PaymentProcessor <> "" Then
                        If Not cboProcessor.Items.FindByText(objPortal.PaymentProcessor) Is Nothing Then
                            cboProcessor.Items.FindByText(objPortal.PaymentProcessor).Selected = True
                        Else       ' default
                            If Not cboProcessor.Items.FindByText("PayPal") Is Nothing Then
                                cboProcessor.Items.FindByText("PayPal").Selected = True
                            End If
                        End If
                    Else
                        cboProcessor.Items.FindByValue("").Selected = True
                    End If
                    txtUserId.Text = objPortal.ProcessorUserId
                    txtPassword.Attributes.Add("value", objPortal.ProcessorPassword)
                    txtHomeDirectory.Text = objPortal.HomeDirectory

                    'Populate the default language combobox
                    Services.Localization.Localization.LoadCultureDropDownList(cboDefaultLanguage, CultureDropDownTypes.NativeName, objPortal.DefaultLanguage)

                    'Populate the timezone combobox (look up timezone translations based on currently set culture)
                    Services.Localization.Localization.LoadTimeZoneDropDownList(cboTimeZone, CType(Page, PageBase).PageCulture.Name, Convert.ToString(objPortal.TimeZoneOffset))

                    Dim objSkin As UI.Skins.SkinInfo

                    ctlPortalSkin.Width = "275px"
                    ctlPortalSkin.SkinRoot = SkinInfo.RootSkin
                    objSkin = SkinController.GetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal)
                    If Not objSkin Is Nothing Then
                        If objSkin.PortalId = PortalId Then
                            ctlPortalSkin.SkinSrc = objSkin.SkinSrc
                        End If
                    End If
                    ctlPortalContainer.Width = "275px"
                    ctlPortalContainer.SkinRoot = SkinInfo.RootContainer
                    objSkin = SkinController.GetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal)
                    If Not objSkin Is Nothing Then
                        If objSkin.PortalId = PortalId Then
                            ctlPortalContainer.SkinSrc = objSkin.SkinSrc
                        End If
                    End If

                    ctlAdminSkin.Width = "275px"
                    ctlAdminSkin.SkinRoot = SkinInfo.RootSkin
                    objSkin = SkinController.GetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin)
                    If Not objSkin Is Nothing Then
                        If objSkin.PortalId = PortalId Then
                            ctlAdminSkin.SkinSrc = objSkin.SkinSrc
                        End If
                    End If
                    ctlAdminContainer.Width = "275px"
                    ctlAdminContainer.SkinRoot = SkinInfo.RootContainer
                    objSkin = SkinController.GetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin)
                    If Not objSkin Is Nothing Then
                        If objSkin.PortalId = PortalId Then
                            ctlAdminContainer.SkinSrc = objSkin.SkinSrc
                        End If
                    End If

                    LoadStyleSheet()

                    If Convert.ToString(PortalSettings.HostSettings("SkinUpload")) = "G" And Not UserInfo.IsSuperUser Then
                        lnkUploadSkin.Visible = False
                        lnkUploadContainer.Visible = False
                    Else
                        Dim FileManagerModule As ModuleInfo = (New ModuleController).GetModuleByDefinition(intPortalId, "File Manager")
                        Dim params(2) As String
                        params(0) = "mid=" & FileManagerModule.ModuleID
                        params(1) = "ftype=" & UploadType.Skin.ToString
                        params(2) = "rtab=" & Me.TabId
                        lnkUploadSkin.NavigateUrl = NavigateURL(FileManagerModule.TabID, "Edit", params)

                        params(1) = "ftype=" & UploadType.Container.ToString
                        lnkUploadContainer.NavigateUrl = NavigateURL(FileManagerModule.TabID, "Edit", params)
                    End If

                    If Not Request.UrlReferrer Is Nothing Then
                        If Request.UrlReferrer.AbsoluteUri = Request.Url.AbsoluteUri Then
                            ViewState("UrlReferrer") = ""
                        Else
                            ViewState("UrlReferrer") = Convert.ToString(Request.UrlReferrer)
                        End If
                    Else
                        ViewState("UrlReferrer") = ""
                    End If

                End If

                If UserInfo.IsSuperUser Then
                    dshHost.Visible = True
                    tblHost.Visible = True
                    cmdDelete.Visible = True
                    If Convert.ToString(ViewState("UrlReferrer")) = "" Then
                        cmdCancel.Visible = False
                    Else
                        cmdCancel.Visible = True
                    End If
                Else
                    dshHost.Visible = False
                    tblHost.Visible = False
                    cmdDelete.Visible = False
                    cmdCancel.Visible = False
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdCancel_Click runs when the Cancel LinkButton is clicked.  It returns the user
        ''' to the referring page
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(Convert.ToString(Viewstate("UrlReferrer")), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDelete_Click runs when the Delete LinkButton is clicked.
        ''' It deletes the current portal form the Database.  It can only run in Host
        ''' (SuperUser) mode
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        '''     [VMasanas]  9/12/2004   Move skin deassignment to DeletePortalInfo.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try

                Dim strServerPath As String
                Dim strPortalName As String

                Dim objPortalController As New PortalController

                ' check if this is the last portal
                Dim arrPortals As ArrayList = objPortalController.GetPortals
                If arrPortals.Count > 1 Then
                    strServerPath = GetAbsoluteServerPath(Request)

                    Dim objPortalInfo As PortalInfo = objPortalController.GetPortal(intPortalId)
                    If Not objPortalInfo Is Nothing Then

                        'If child portal delete child folder
                        Dim objPortalAliasController As New PortalAliasController
                        Dim arr As ArrayList = objPortalAliasController.GetPortalAliasArrayByPortalID(intPortalId)
                        Dim objPortalAliasInfo As PortalAliasInfo = CType(arr(0), PortalAliasInfo)
                        strPortalName = GetPortalDomainName(objPortalAliasInfo.HTTPAlias)
                        If Convert.ToBoolean(InStr(1, objPortalAliasInfo.HTTPAlias, "/")) Then
                            strPortalName = Mid(objPortalAliasInfo.HTTPAlias, InStrRev(objPortalAliasInfo.HTTPAlias, "/") + 1)
                        End If
                        If strPortalName <> "" AndAlso System.IO.Directory.Exists(strServerPath & strPortalName) Then
                            DeleteFolderRecursive(strServerPath & strPortalName)
                        End If

                        ' delete upload directory
                        DeleteFolderRecursive(strServerPath & "Portals\" & objPortalInfo.PortalID.ToString)
                        Dim HomeDirectory As String = objPortalInfo.HomeDirectoryMapPath
                        If System.IO.Directory.Exists(HomeDirectory) Then
                            DeleteFolderRecursive(HomeDirectory)
                        End If

                        ' delete custom resource files
                        DeleteFilesRecursive(strServerPath, ".Portal-" + objPortalInfo.PortalID.ToString + ".resx")

                        ' remove database references
                        objPortalController.DeletePortalInfo(intPortalId)

                        Dim objEventLog As New Services.Log.EventLog.EventLogController
						objEventLog.AddLog("PortalName", txtPortalName.Text, PortalSettings, UserId, Services.Log.EventLog.EventLogController.EventLogType.PORTAL_DELETED)

                    End If

                    ' Redirect to another site
                    If intPortalId = PortalId Then
                        If PortalSettings.HostSettings("HostURL").ToString <> "" Then
                            Response.Redirect(AddHTTP(PortalSettings.HostSettings("HostURL").ToString))
                        Else
                            Response.End()
                        End If
                    Else
                        Response.Redirect(Convert.ToString(Viewstate("UrlReferrer")), True)
                    End If
                Else
                    Dim strMessage As String = Services.Localization.Localization.GetString("LastPortal", Me.LocalResourceFile)
                    UI.Skins.Skin.AddModuleMessage(Me, strMessage, UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdGoogle_Click runs when the Submit to Google Linkbutton is clicked. 
        ''' It submits the site's Description, DomainName and Keywords to the Google Site.
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdGoogle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGoogle.Click
            Try

                Dim strURL As String = ""
                Dim strComments As String = ""

                Dim objPortalController As New PortalController
                Dim objPortal As PortalInfo = objPortalController.GetPortal(intPortalId)
                If Not objPortal Is Nothing Then
                    strComments += objPortal.PortalName
                    If objPortal.Description <> "" Then
                        strComments += " " & objPortal.Description
                    End If
                    If objPortal.KeyWords <> "" Then
                        strComments += " " & objPortal.KeyWords
                    End If
                End If

                strURL += "http://www.google.com/addurl?q=" & HTTPPOSTEncode(AddHTTP(GetDomainName(Request)))
                strURL += "&dq=" & HTTPPOSTEncode(strComments)
                strURL += "&submit=Add+URL"

                Response.Redirect(strURL, True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdProcessor_Click runs when the Processor Website Linkbutton is clicked. It
        ''' redirects the user to the selected processor's website.
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdProcessor_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProcessor.Click
            Try
                Response.Redirect(AddHTTP(cboProcessor.SelectedItem.Value), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdRestore_Click runs when the Restore Default Stylesheet Linkbutton is clicked. 
        ''' It reloads the default stylesheet (copies from _default Portal to current Portal)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdRestore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRestore.Click
            Try
                Dim strServerPath As String = Request.MapPath(Common.Globals.ApplicationPath)

                Dim objPortalController As New PortalController
                Dim objPortal As PortalInfo = objPortalController.GetPortal(intPortalId)
                If Not objPortal Is Nothing Then
                    If System.IO.File.Exists(objPortal.HomeDirectoryMapPath + "portal.css") Then
                        ' delete existing style sheet
                        System.IO.File.Delete(objPortal.HomeDirectoryMapPath + "portal.css")
                    End If
                    ' copy the default style sheet to the upload directory
                    System.IO.File.Copy(Common.Globals.HostMapPath + "portal.css", objPortal.HomeDirectoryMapPath + "portal.css")
                End If

                LoadStyleSheet()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdSave_Click runs when the Save Stylesheet Linkbutton is clicked.  It saves
        ''' the edited Stylesheet
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            Try
                Dim strUploadDirectory As String = ""

                Dim objPortalController As New PortalController
                Dim objPortal As PortalInfo = objPortalController.GetPortal(intPortalId)
                If Not objPortal Is Nothing Then
                    strUploadDirectory = objPortal.HomeDirectoryMapPath
                End If

                ' reset attributes
                If File.Exists(strUploadDirectory & "portal.css") Then
                    File.SetAttributes(strUploadDirectory & "portal.css", FileAttributes.Normal)
                End If

                ' write CSS file
                Dim objStream As StreamWriter
                objStream = File.CreateText(strUploadDirectory & "portal.css")
                objStream.WriteLine(txtStyleSheet.Text)
                objStream.Close()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the Update LinkButton is clicked.
        ''' It saves the current Site Settings
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/9/2004	Modified
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                Dim strLogo As String
                Dim strBackground As String

                strLogo = ctlLogo.Url
                strBackground = ctlBackground.Url


                Dim dblHostFee As Double = 0
                If txtHostFee.Text <> "" Then
                    dblHostFee = Double.Parse(txtHostFee.Text)
                End If

                Dim dblHostSpace As Double = 0
                If txtHostSpace.Text <> "" Then
                    dblHostSpace = Double.Parse(txtHostSpace.Text)
                End If

                Dim intSiteLogHistory As Integer = -1
                If txtSiteLogHistory.Text <> "" Then
                    intSiteLogHistory = Integer.Parse(txtSiteLogHistory.Text)
                End If

                Dim datExpiryDate As Date = Null.NullDate
                If txtExpiryDate.Text <> "" Then
                    datExpiryDate = Convert.ToDateTime(txtExpiryDate.Text)
                End If

                Dim intSplashTabId As Integer = Null.NullInteger
                If Not cboSplashTabId.SelectedItem Is Nothing Then
                    intSplashTabId = Integer.Parse(cboSplashTabId.SelectedItem.Value)
                End If

                Dim intHomeTabId As Integer = Null.NullInteger
                If Not cboHomeTabId.SelectedItem Is Nothing Then
                    intHomeTabId = Integer.Parse(cboHomeTabId.SelectedItem.Value)
                End If

                Dim intLoginTabId As Integer = Null.NullInteger
                If Not cboLoginTabId.SelectedItem Is Nothing Then
                    intLoginTabId = Integer.Parse(cboLoginTabId.SelectedItem.Value)
                End If

                Dim intUserTabId As Integer = Null.NullInteger
                If Not cboUserTabId.SelectedItem Is Nothing Then
                    intUserTabId = Integer.Parse(cboUserTabId.SelectedItem.Value)
                End If

                If Not txtPassword.Attributes.Item("value") Is Nothing Then
                    txtPassword.Attributes.Item("value") = txtPassword.Text
                End If

                ' update Portal info in the database
                Dim objPortalController As New PortalController
                'check only relevant fields altered
                If Not UserInfo.IsSuperUser Then
                    Dim objPortal As PortalInfo = objPortalController.GetPortal(intPortalId)
                    Dim HostChanged As Boolean = False
                    If dblHostFee <> objPortal.HostFee Then HostChanged = True
                    If dblHostSpace <> objPortal.HostSpace Then HostChanged = True
                    If intSiteLogHistory <> objPortal.SiteLogHistory Then HostChanged = True
                    If datExpiryDate <> objPortal.ExpiryDate Then HostChanged = True
                    If HostChanged = True Then
                        Throw New System.Exception
                    End If
                End If

                Dim objModules As New ModuleController
                objPortalController.UpdatePortalInfo(intPortalId, txtPortalName.Text, strLogo, txtFooterText.Text, datExpiryDate, optUserRegistration.SelectedIndex, optBannerAdvertising.SelectedIndex, cboCurrency.SelectedItem.Value, Convert.ToInt32(cboAdministratorId.SelectedItem.Value), dblHostFee, dblHostSpace, IIf(cboProcessor.SelectedValue = "", "", cboProcessor.SelectedItem.Text).ToString, txtUserId.Text, txtPassword.Text, txtDescription.Text, txtKeyWords.Text, strBackground, intSiteLogHistory, intSplashTabId, intHomeTabId, intLoginTabId, intUserTabId, cboDefaultLanguage.SelectedValue, Convert.ToInt32(cboTimeZone.SelectedValue), txtHomeDirectory.Text)
                Dim blnAdminSkinChanged As Boolean = SkinChanged(SkinInfo.RootSkin, PortalId, SkinType.Admin, ctlAdminSkin.SkinSrc) OrElse SkinChanged(SkinInfo.RootContainer, PortalId, SkinType.Admin, ctlAdminContainer.SkinSrc)

                'Dim objSkins As New UI.Skins.SkinController
                SkinController.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal, ctlPortalSkin.SkinSrc)
                SkinController.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, ctlPortalContainer.SkinSrc)
                SkinController.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin, ctlAdminSkin.SkinSrc)
                SkinController.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, ctlAdminContainer.SkinSrc)

                If UserInfo.IsSuperUser Then
                    ' delete old portal module assignments
                    Dim objDesktopModules As New DesktopModuleController
                    objDesktopModules.DeletePortalDesktopModules(intPortalId, Null.NullInteger)
                    ' add new portal module assignments
                    Dim objListItem As ListItem
                    For Each objListItem In ctlDesktopModules.Assigned
                        objDesktopModules.AddPortalDesktopModule(intPortalId, Integer.Parse(objListItem.Value))
                    Next
                End If

                ' Redirect to this site to refresh only if admin skin changed
                If blnAdminSkinChanged Then Response.Redirect(Request.RawUrl, True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace

