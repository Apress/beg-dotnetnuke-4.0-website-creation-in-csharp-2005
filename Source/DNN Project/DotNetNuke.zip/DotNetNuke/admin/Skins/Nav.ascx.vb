'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.UI.WebControls
Imports DotNetNuke.UI.Navigation

Namespace DotNetNuke.UI.Skins.Controls

	Partial  Class Nav
		Inherits UI.Skins.NavObjectBase

		' protected controls

#Region "Public Members"



#End Region


#Region " Web Form Designer Generated Code "


		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

		'*******************************************************
		'
		' The Page_Load server event handler on this page is used
		' to populate the role information for the page
		'
		'*******************************************************

		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				Dim blnIndicateChildren As Boolean = Boolean.Parse(GetValue(Me.IndicateChildren, "True"))				 'This setting determines if the submenu arrows will be used
				'Dim blnRootOnly As Boolean = Boolean.Parse(GetValue(RootOnly, "False"))				'This setting determines if the submenu will be shown
				Dim strRightArrow As String
				Dim strDownArrow As String

				'If blnRootOnly Then blnIndicateChildren = False

				Dim objSkins As New UI.Skins.SkinController

				'image for right facing arrow
				If IndicateChildImageSub <> "" Then
					strRightArrow = IndicateChildImageSub
				Else
					strRightArrow = "breadcrumb.gif"
				End If
				'image for down facing arrow
				If IndicateChildImageRoot <> "" Then
					strDownArrow = IndicateChildImageRoot
				Else
					strDownArrow = "menu_down.gif"
				End If

				'Set correct image path for all separator images
				If SeparatorHTML <> "" Then
					If SeparatorHTML.IndexOf("src=") <> -1 Then
						SeparatorHTML = Replace(SeparatorHTML, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If

				If SeparatorLeftHTML <> "" Then
					If SeparatorLeftHTML.IndexOf("src=") <> -1 Then
						SeparatorLeftHTML = Replace(SeparatorLeftHTML, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If
				If SeparatorRightHTML <> "" Then
					If SeparatorRightHTML.IndexOf("src=") <> -1 Then
						SeparatorRightHTML = Replace(SeparatorRightHTML, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If
				If SeparatorLeftHTMLBreadCrumb <> "" Then
					If SeparatorLeftHTMLBreadCrumb.IndexOf("src=") <> -1 Then
						SeparatorLeftHTMLBreadCrumb = Replace(SeparatorLeftHTMLBreadCrumb, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If
				If SeparatorRightHTMLBreadCrumb <> "" Then
					If SeparatorRightHTMLBreadCrumb.IndexOf("src=") <> -1 Then
						SeparatorRightHTMLBreadCrumb = Replace(SeparatorRightHTMLBreadCrumb, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If
				If SeparatorLeftHTMLActive <> "" Then
					If SeparatorLeftHTMLActive.IndexOf("src=") <> -1 Then
						SeparatorLeftHTMLActive = Replace(SeparatorLeftHTMLActive, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If
				If SeparatorRightHTMLActive <> "" Then
					If SeparatorRightHTMLActive.IndexOf("src=") <> -1 Then
						SeparatorRightHTMLActive = Replace(SeparatorRightHTMLActive, "src=""", "src=""" & PortalSettings.ActiveTab.SkinPath)
					End If
				End If

				If Len(Me.PathImage) = 0 Then
					Me.PathImage = PortalSettings.HomeDirectory
				End If
				If blnIndicateChildren Then
					Me.IndicateChildImageSub = strRightArrow
					'Me.IndicateChildren = True.ToString
					If Me.ControlOrientation.ToLower = "vertical" Then					 'NavigationProvider.NavigationProvider.Orientation.Vertical Then
						Me.IndicateChildImageRoot = strRightArrow
					Else
						Me.IndicateChildImageRoot = strDownArrow
					End If
				Else
					Me.PathSystemImage = Common.Globals.ApplicationPath & "/images/"
					Me.IndicateChildImageSub = "spacer.gif"
				End If
				Me.PathSystemScript = Common.Globals.ApplicationPath & "/controls/SolpartMenu/"

				BuildNodes(Nothing)

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		Private Sub BuildNodes(ByVal objNode As WebControls.DNNNode)
			Dim objNodes As DNNNodeCollection
			objNodes = GetNavigationNodes(objNode)

			Me.Bind(objNodes)
		End Sub

		Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
			InitializeNavControl(Me, "SolpartMenuNavigationProvider")
			MyBase.OnInit(e)
		End Sub
	End Class

End Namespace
