Imports System
Imports System.Configuration
Imports System.Data

Namespace YourCompany.Modules.GuestBook

  Public Class GuestBookInfo

    Private _ModuleId As Integer
    Private _ID As Integer
    Private _Name As String
    Private _Email As String
    Private _Message As String
    Private _DateEntered As DateTime

    ' initialization

    Public Sub New()
      MyBase.New()
    End Sub

    ' <summary>
    ' Gets and sets the Module Id
    ' </summary>

    Public Property ModuleId() As Integer
      Get
        Return _ModuleId
      End Get
      Set(ByVal value As Integer)
        _ModuleId = value
      End Set
    End Property


    ' <summary>
    ' Gets and sets the Item ID
    ' </summary>
    Public Property ID() As Integer
      Get
        Return _ID
      End Get
      Set(ByVal value As Integer)
        _ID = value
      End Set
    End Property


    ' <summary>
    ' gets and sets the Name
    ' </summary>
    Public Property Name() As String
      Get
        Return _Name
      End Get
      Set(ByVal value As String)
        _Name = value
      End Set
    End Property


    ' <summary>
    ' Gets and sets the Email
    ' </summary>
    Public Property Email() As String
      Get
        Return _Email
      End Get
      Set(ByVal value As String)
        _Email = value
      End Set
    End Property


    ' <summary>
    ' Gets and sets the Message
    ' </summary>
    Public Property Message() As String
      Get
        Return _Message
      End Get
      Set(ByVal value As String)
        _Message = value
      End Set
    End Property


    ' <summary>
    ' Gets and sets the DateEntered
    ' </summary>
    Public Property DateEntered() As DateTime
      Get
        Return _DateEntered
      End Get
      Set(ByVal value As DateTime)
        _DateEntered = value
      End Set
    End Property


  End Class
End Namespace