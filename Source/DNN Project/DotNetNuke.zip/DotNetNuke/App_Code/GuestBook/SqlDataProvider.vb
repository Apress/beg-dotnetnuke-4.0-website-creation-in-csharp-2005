Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.ApplicationBlocks.Data
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Framework.Providers

Namespace YourCompany.Modules.GuestBook

  Public Class SqlDataProvider
    Inherits DataProvider

    Private Const ProviderType As String = "data"
    Private Const ModuleQualifier As String = ""
    Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
    Private _connectionString As String
    Private _providerPath As String
    Private _objectQualifier As String
    Private _databaseOwner As String

    ' <summary>
    ' Constructs new SqlDataProvider instance
    ' </summary>
    Public Sub New()
      MyBase.New()
      'Read the configuration specific information for this provider
      Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)
      'Read the attributes for this provider
      If ((objProvider.Attributes("connectionStringName") <> "") _
      AndAlso (System.Configuration.ConfigurationManager.AppSettings(objProvider.Attributes("connectionStringName")) <> "")) Then
        _connectionString = System.Configuration.ConfigurationManager.AppSettings(objProvider.Attributes("connectionStringName"))
      Else
        _connectionString = objProvider.Attributes("connectionString")
      End If
      _providerPath = objProvider.Attributes("providerPath")
      _objectQualifier = objProvider.Attributes("objectQualifier")
      If ((_objectQualifier <> "") _
      AndAlso (_objectQualifier.EndsWith("_") = False)) Then
        _objectQualifier = (_objectQualifier + "_")
      End If
      _databaseOwner = objProvider.Attributes("databaseOwner")
      If ((_databaseOwner <> "") _
      AndAlso (_databaseOwner.EndsWith(".") = False)) Then
        _databaseOwner = (_databaseOwner + ".")
      End If
    End Sub

    ' <summary>
    ' Gets and sets the connection string
    ' </summary>
    Public ReadOnly Property ConnectionString() As String
      Get
        Return _connectionString
      End Get
    End Property

    ' <summary>
    ' Gets and sets the Provider path
    ' </summary>
    Public ReadOnly Property ProviderPath() As String
      Get
        Return _providerPath
      End Get
    End Property

    ' <summary>
    ' Gets and sets the Object qualifier
    ' </summary>
    Public ReadOnly Property ObjectQualifier() As String
      Get
        Return _objectQualifier
      End Get
    End Property

    ' <summary>
    ' Gets and sets the database ownere
    ' </summary>
    Public ReadOnly Property DatabaseOwner() As String
      Get
        Return _databaseOwner
      End Get
    End Property

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' Gets the fully qualified name of the stored procedure
    ' </summary>
    ' <param name="name">The name of the stored procedure</param>
    ' <returns>The fully qualified name</returns>
    ' -----------------------------------------------------------------------------
    Private Function GetFullyQualifiedName(ByVal name As String) As String
      Return (DatabaseOwner _
      + (ObjectQualifier _
      + (ModuleQualifier + name)))
    End Function

    ' -----------------------------------------------------------------------------
    ' <summary>
    ' Gets the value for the field or DbNull if field has "null" value
    ' </summary>
    ' <param name="Field">The field to evaluate</param>
    ' <returns></returns>
    ' -----------------------------------------------------------------------------
    Private Function GetNull(ByVal Field As Object) As Object
      Return Null.GetNull(Field, DBNull.Value)
    End Function

    Public Overrides Sub YourCompany_GuestBook_Insert(ByVal ModuleId As Integer, ByVal Name As String, ByVal Email As String, ByVal Message As String)
      SqlHelper.ExecuteNonQuery(ConnectionString, GetFullyQualifiedName("YourCompany_GuestBook_Insert"), ModuleId, Name, Email, Message)
    End Sub

    Public Overrides Sub YourCompany_GuestBook_Delete(ByVal ID As Integer)
      SqlHelper.ExecuteNonQuery(ConnectionString, GetFullyQualifiedName("YourCompany_GuestBook_Delete"), ID)
    End Sub

    Public Overrides Function YourCompany_GuestBook_GetAll(ByVal ModuleId As Integer) As IDataReader
      Return CType(SqlHelper.ExecuteReader(ConnectionString, GetFullyQualifiedName("YourCompany_GuestBook_GetAll"), ModuleId), IDataReader)
    End Function

    Public Overrides Sub YourCompany_GuestBook_Update(ByVal ID As Integer, ByVal Name As String, ByVal Email As String, ByVal Message As String, ByVal DateEntered As DateTime)
      SqlHelper.ExecuteNonQuery(ConnectionString, GetFullyQualifiedName("YourCompany_GuestBook_Update"), ID, Name, Email, Message, DateEntered)
    End Sub
  End Class
End Namespace