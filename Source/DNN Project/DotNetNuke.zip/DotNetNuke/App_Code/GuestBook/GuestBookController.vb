Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.ComponentModel
Imports System.Data
Imports System.Xml
Imports System.Web
Imports DotNetNuke
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Services.Search


Namespace YourCompany.Modules.GuestBook

  Public Class GuestBookController

    <DataObjectMethod(DataObjectMethodType.Insert)> _
    Public Shared Sub GuestBook_Insert(ByVal objTest As GuestBookInfo)
      DataProvider.Instance.YourCompany_GuestBook_Insert(objTest.ModuleId, objTest.Name, objTest.Email, objTest.Message)
    End Sub

    <DataObjectMethod(DataObjectMethodType.Delete)> _
    Public Shared Sub GuestBook_Delete(ByVal objTest As GuestBookInfo)
      DataProvider.Instance.YourCompany_GuestBook_Delete(objTest.ID)
    End Sub

    <DataObjectMethod(DataObjectMethodType.Select)> _
    Public Shared Function GuestBook_GetAll(ByVal ModuleId As Integer) As List(Of GuestBookInfo)
      Return CBO.FillCollection(Of GuestBookInfo)(DataProvider.Instance().YourCompany_GuestBook_GetAll(ModuleId))
    End Function

    <DataObjectMethod(DataObjectMethodType.Update)> _
    Public Shared Sub GuestBook_Update(ByVal objTest As GuestBookInfo)
      DataProvider.Instance.YourCompany_GuestBook_Update(objTest.ID, objTest.Name, objTest.Email, objTest.Message, objTest.DateEntered)
    End Sub

  End Class


End Namespace