Imports System
Imports DotNetNuke
Imports System.Data
Imports DotNetNuke.Framework

Namespace YourCompany.Modules.GuestBook

  Public MustInherit Class DataProvider
    ' singleton reference to the instantiated object
    Private Shared objProvider As DataProvider = Nothing

    ' constructor
    Shared Sub New()
      CreateProvider()

    End Sub

    ' dynamically create provider
    Private Shared Sub CreateProvider()
      objProvider = CType(Reflection.CreateObject("data", "YourCompany.Modules.GuestBook", ""), DataProvider)
    End Sub

    ' return the provider
    Public Shared Function Instance() As DataProvider
      Return objProvider
    End Function

    Public MustOverride Sub YourCompany_GuestBook_Insert(ByVal ModuleId As Integer, ByVal Name As String, ByVal Email As String, ByVal Message As String)
    Public MustOverride Function YourCompany_GuestBook_GetAll(ByVal ModuleId As Integer) As IDataReader
    Public MustOverride Sub YourCompany_GuestBook_Update(ByVal ID As Integer, ByVal Name As String, ByVal Email As String, ByVal Message As String, ByVal DateEntered As DateTime)
    Public MustOverride Sub YourCompany_GuestBook_Delete(ByVal ID As Integer)

  End Class

End Namespace